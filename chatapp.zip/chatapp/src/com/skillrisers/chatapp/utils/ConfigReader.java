package com.skillrisers.chatapp.utils;

public class ConfigReader {

}
