package com.skillrisers.chatapp.repository;

public class UserRepository {

}
