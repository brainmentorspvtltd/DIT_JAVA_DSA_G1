package com.skillrisers.chatapp.views;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

public class UserView extends JFrame {

	private JPanel contentPane;
	private JTextField useridtxt;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserView frame = new UserView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UserView() {
		setResizable(false);
		
		setTitle("Login/Register");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Login / Register");
		lblNewLabel.setForeground(new Color(255, 46, 37));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		lblNewLabel.setBounds(161, 22, 170, 25);
		contentPane.add(lblNewLabel);
		
		JLabel useridlbl = new JLabel("Userid");
		useridlbl.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		useridlbl.setBounds(43, 84, 89, 16);
		contentPane.add(useridlbl);
		
		JLabel pwdlbl = new JLabel("Password");
		
		pwdlbl.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		pwdlbl.setBounds(43, 131, 108, 16);
		contentPane.add(pwdlbl);
		
		useridtxt = new JTextField();
		useridtxt.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		useridtxt.setBounds(136, 76, 206, 30);
		contentPane.add(useridtxt);
		useridtxt.setColumns(10);
		
		passwordField = new JPasswordField();
		//passwordField.setEchoChar(0)
		passwordField.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		passwordField.setBounds(136, 127, 206, 30);
		contentPane.add(passwordField);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setBounds(53, 197, 117, 29);
		contentPane.add(btnLogin);
		
		JButton btnRegister = new JButton("Register");
		btnRegister.setBounds(184, 197, 117, 29);
		contentPane.add(btnRegister);
		setLocationRelativeTo(null);
		
	}
}
