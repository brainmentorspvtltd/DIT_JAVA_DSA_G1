package com.skillrisers.gaming.canvas;

import javax.swing.JFrame;

public class GameFrame extends JFrame {
	
	public GameFrame() {
		setResizable(false);
		setTitle("Street Fighter Game ");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(1400, 900);
		setLocationRelativeTo(null);
		Board board = new Board();
		add(board); // Board added in Frame.
		setVisible(true);
		
	}

	public static void main(String[] args) {
		GameFrame obj = new GameFrame();

	}

}
