package com.skillrisers.gaming.canvas;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class Board extends JPanel {
	BufferedImage imageBg;
	public Board() {
		loadBackgroundImage();
	}
	
	@Override
	public void paintComponent(Graphics pen) {
		// Rendering / Painting
		printBackgroundImage(pen);
		
	}
	
	private void printBackgroundImage(Graphics pen) {
		pen.drawImage(imageBg,0,0, 1400,900, null);
	}
	
	private void loadBackgroundImage() {
		try {
			imageBg = ImageIO.read(Board.class.getResource("bg.jpeg"));
			}
			catch(Exception ex) {
				System.out.println("Background Image Loading Fail...");
				System.exit(0);
			
			}
	}
}
