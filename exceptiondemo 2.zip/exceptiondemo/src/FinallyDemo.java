import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FinallyDemo {
	
	static void readFile() throws IOException {
		String path  = "/Users/amitsrivastava/Documents/game-street-fighter/exceptiondemo/src/FinallyDemo.java";
		FileInputStream fs = new FileInputStream(path);
		try {
		byte b[] = fs.readAllBytes(); // throw new IOException
		String data = new String(b);
		System.out.println(data);
		if(10>2) {
			System.exit(0);
			//return ;
		}
		System.out.println("Never Execute...");
		}
		finally {
			// resource clean up (file close, db connection close, socket close)
			System.out.println("Always Execute....");
		fs.close();
		}
		
	}

	public static void main(String[] args) {
		try {
			readFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		// try + finally 
		//finally - it is a always execute block
		

	}

}
