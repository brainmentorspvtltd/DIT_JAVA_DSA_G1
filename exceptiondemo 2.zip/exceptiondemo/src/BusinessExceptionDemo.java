import java.util.Scanner;

class MinorAgeException extends Exception{
	int age;
	MinorAgeException(int age){
		this.age = age;
	}
	@Override
	public String toString() {
		return "MinorAge Exception occur due to Age is less than 18 ur entered age is "+age;
	}
	
}
public class BusinessExceptionDemo {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Age");
		int age = scanner.nextInt();
		try {
		if(age<18) {
			throw new MinorAgeException(age);
		}
		System.out.println("Apply FOR DL SuccessFully....");
		}
		catch (MinorAgeException e) {
			System.out.println(e);
			//System.out.println("Age can't be less than 18 for DL "+e.toString());
			e.printStackTrace();
			// TODO: handle exception
		}
		catch(Exception e) {
			System.out.println("Something went wrong... ");
			e.printStackTrace();
		}
		finally {
			scanner.close();
		}
		

	}

}
