import java.io.FileInputStream;
import java.io.IOException;

public class TryWithResource {

	static void readFile() throws IOException {
		String path  = "/Users/amitsrivastava/Documents/game-street-fighter/exceptiondemo/src/FinallyDemo.java";
		try(FileInputStream fs = new FileInputStream(path)){
		
		byte b[] = fs.readAllBytes(); // throw new IOException
		String data = new String(b);
		System.out.println(data);
		if(10>2) {
			System.exit(0);
			//return ;
		}
		System.out.println("Never Execute...");
		
		
			// resource clean up (file close, db connection close, socket close)
			System.out.println("Always Execute....");
		
		
		
	} // try with resource clean
	}
	
	public static void main(String[] args) {
		try {
			readFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
