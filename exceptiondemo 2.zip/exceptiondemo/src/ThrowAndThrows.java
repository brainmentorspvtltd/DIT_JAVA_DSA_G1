import java.sql.SQLException;

public class ThrowAndThrows {
	static void db() throws SQLException{
		// DB Connect Code
		throw new SQLException(); 
	}
	static void logic() throws SQLException {
		// Business Logic Code
		db();
	}
	static void view() throws SQLException {
		// Present Code
		logic();
	}
	public static void main(String[] args) {
		try {
		view();
		}
		catch(SQLException e) {
			System.out.println("Might be DB is Down....");
			e.printStackTrace();
		}
	}
}
