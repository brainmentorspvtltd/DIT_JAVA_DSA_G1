package com.skillrisers.gaming.canvas;

import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import com.skillrisers.gaming.sprites.OppPlayer;
import com.skillrisers.gaming.sprites.Player;
import com.skillrisers.gaming.utils.GameConstants;

public class Board extends JPanel implements GameConstants {
	BufferedImage imageBg;
	private Player player;
	private OppPlayer oppPlayer;
	public Board() throws Exception {
		player = new Player();
		oppPlayer = new OppPlayer();
		loadBackgroundImage();
		setFocusable(true);
		bindEvents();
	}
	
	private void bindEvents() {
		KeyListener listener = new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				System.out.println("Typed "+e.getKeyCode() + " "+e.getKeyChar());
				
			}
			
			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				System.out.println("Release "+e.getKeyCode() + " "+e.getKeyChar());
				
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				// Left Ryu
				if(e.getKeyCode() == KeyEvent.VK_LEFT) {
					player.setSpeed(-SPEED);
					player.move();
					System.out.println("X LEFT "+player.getX());
					repaint();
				}
				if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
					player.setSpeed(SPEED);
					player.move();
					
					System.out.println("X RIGHT "+player.getX());
					repaint();
				}
				
				// Ken 
				
				if(e.getKeyCode() == KeyEvent.VK_J) {
					oppPlayer.setSpeed(-SPEED);
					oppPlayer.move();
					//System.out.println("X LEFT "+player.getX());
					repaint();
				}
				if(e.getKeyCode() == KeyEvent.VK_L) {
					oppPlayer.setSpeed(SPEED);
					oppPlayer.move();
					
					//System.out.println("X RIGHT "+player.getX());
					repaint();
				}
				
				
				// TODO Auto-generated method stub
				//System.out.println("Press "+e.getKeyCode() + " "+e.getKeyChar());
				
			}
		};
		this.addKeyListener(listener);
	}
	
	@Override
	public void paintComponent(Graphics pen) {
		// Rendering / Painting
		printBackgroundImage(pen);
		player.drawPlayer(pen);
		oppPlayer.drawPlayer(pen);
		
		
	}

	
	private void printBackgroundImage(Graphics pen) {
		pen.drawImage(imageBg,0,0, GWIDTH,GHEIGHT, null);
	}
	
	
	
	private void loadBackgroundImage() {
		try {
			imageBg = ImageIO.read(Board.class.getResource(BG_IMG));
			}
			catch(Exception ex) {
				System.out.println("Background Image Loading Fail...");
				System.exit(0);
			
			}
	}
}
