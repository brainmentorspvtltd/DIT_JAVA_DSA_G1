package com.skillrisers.gaming.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import com.skillrisers.gaming.utils.GameConstants;

public class Player extends CommonPlayer implements GameConstants {
	
	public Player() throws Exception {
		x = 100;
		h = w = 200;
		y = FLOOR - h;
		image = ImageIO.read(Player.class.getResource(PLAYER_IMG));
		speed=SPEED;
	}
	@Override 
	public BufferedImage walk() {
		return image.getSubimage(61, 234, 74, 105);
	}
	
}
