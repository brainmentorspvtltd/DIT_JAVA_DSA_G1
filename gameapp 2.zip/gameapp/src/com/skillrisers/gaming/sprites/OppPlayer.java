package com.skillrisers.gaming.sprites;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.skillrisers.gaming.utils.GameConstants;

public class OppPlayer extends CommonPlayer implements GameConstants {
	
	public OppPlayer() throws IOException {
		x = GWIDTH - 300;
		h = w = 200;
		y = FLOOR- h;
		speed = SPEED;
		image = ImageIO.read(OppPlayer.class.getResource(OPP_PLAYER_IMG));
	}

	@Override
	public BufferedImage walk() {
		// TODO Auto-generated method stub
		return image.getSubimage(1263, 863, 64, 93);
		
	}
	

}
