package com.skillrisers.gaming.utils;

public interface GameConstants {
	int GWIDTH = 1400;
	int GHEIGHT = 900;
	String TITLE = "Street Fighter Game ";
	int FLOOR = GHEIGHT - 150;
	int SPEED = 10;
	String OPP_PLAYER_IMG = "kenimage.png";
	String PLAYER_IMG  = "player-sprite.gif";
	String BG_IMG = "bg.jpeg";
	
}
