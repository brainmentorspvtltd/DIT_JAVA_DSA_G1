package com.skillrisers.gaming.sprites;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class KenPlayer extends Sprite {
	BufferedImage damageEffectImages[] = new BufferedImage[5];
	public KenPlayer() throws IOException {
		x = GWIDTH - 400;
		h = 200;
		w = 200;
		y = FLOOR - h;
		imageIndex = 0;
		currentMove = WALK;
		speed = 0;
		image = ImageIO.read(RyuPlayer.class.getResource(KEN_IMAGE));
		loadDamageEffect();
	}
	
	public void loadDamageEffect() {
		damageEffectImages[0]  = image.getSubimage(1365,3276,65,95);
		damageEffectImages[1]  = image.getSubimage(1437,3271,88,99);
		damageEffectImages[2]  = image.getSubimage(1537,3278,75,91);
		damageEffectImages[3]  = image.getSubimage(1627,3277,70,92);
		damageEffectImages[4]  = image.getSubimage(1712	,3274,63,98);
	}
	
	public BufferedImage printDamageImage() {
		if(imageIndex>damageEffectImages.length-1) {
			imageIndex = 0;
			currentMove = WALK;
		}
		BufferedImage img =  damageEffectImages[imageIndex];
		imageIndex++;
		return img;
		
	}
	
	@Override
	public BufferedImage defaultImage() {
		if(currentMove == WALK)
		return   image.getSubimage(1756,685,62,94);
		else {
			return printDamageImage();
		}
	}
	
}
