import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionHandlingDemo {
	Scanner scanner = new Scanner(System.in);
	int firstNumber;
	int secondNumber;
	int result;
	void takeFirstInput() {
		try {
		System.out.println("Enter the First Number");
		// throw Implicit / System define exception
		firstNumber = scanner.nextInt(); // throw new InputMismatchException()
		}
		catch(InputMismatchException e) {
			scanner.nextLine();  // eat \n
			System.out.println("Invalid First Number use 0 to 9 in form of digits so it will accept");
			takeFirstInput();
		}
	}
	void takeSecondInput() {
		try {
		System.out.println("Enter the Second Number");
		// throw Implicit / System define exception
		secondNumber = scanner.nextInt(); // throw new InputMismatchException()
		}
		catch(InputMismatchException e) {
			scanner.nextLine();  // eat \n
			System.out.println("Invalid Second Number use 0 to 9 in form of digits so it will accept");
			takeSecondInput();
		}
	}
	
	void divide() {
		try {
		result = firstNumber/ secondNumber;
		}
		catch(ArithmeticException e) {
			takeSecondInput();
			divide();
		}
		
	}
	
	void print() {
		try {
		System.out.println("Result is "+result);
		}
		finally {
			if(scanner!=null) {
			scanner.close();
			}
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExceptionHandlingDemo obj = new ExceptionHandlingDemo();
		obj.takeFirstInput();
		obj.takeSecondInput();
		obj.divide();
		obj.print();
		
		
//		System.out.println("Enter the Second Number");
//		int secondNumber = scanner.nextInt(); // throw new InputMismatchException()
//		int result= firstNumber + secondNumber;
//		System.out.println("Result is "+result);
//		scanner.close();

	}

}
